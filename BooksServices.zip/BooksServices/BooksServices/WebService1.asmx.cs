﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
namespace BooksServices
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        BookDataContext conn = new BookDataContext();
        
        
        [WebMethod]

        public void insert(string id, string title, string author)
        {
            var ids = from Book in conn.Books
                      where Book.ID == id
                      select Book;
            if (ids == null)
            {
                Book nwbook = new Book();
            nwbook.ID = id;
            nwbook.Title = title;
            nwbook.Author = author;
            conn.Books.InsertOnSubmit(nwbook);
            conn.SubmitChanges();
            Console.WriteLine("Oke inserted");
        }
           
    }
        [WebMethod]
        public Book search(string id)
        {
            Book a = new Book();
            a.ID = "-1";
            var ids = from Book in conn.Books
                      where Book.ID == id
                      select Book;
            if (ids.Count() == 0)
            {
                return a;
            }

            return ids.First();
        }
        [WebMethod]
        public void delete(string id)
        {
            var ids = from Book in conn.Books
                          where Book.ID == id
                          select Book;
            if(ids == null)
            {
                return;
            }
            foreach (var idd in ids)
            {
                conn.Books.DeleteOnSubmit(idd);
            }
            conn.SubmitChanges();
            Console.WriteLine("Deleted");
        }
    }
}
