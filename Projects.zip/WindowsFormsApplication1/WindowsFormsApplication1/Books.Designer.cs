﻿namespace WindowsFormsApplication1
{
    partial class Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.idDel = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.idIns = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.titleIns = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.authorIns = new System.Windows.Forms.TextBox();
            this.btnIns = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(92, 64);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(69, 21);
            this.btnDel.TabIndex = 0;
            this.btnDel.Text = "Delete";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "INSERT ->";
            // 
            // idDel
            // 
            this.idDel.Location = new System.Drawing.Point(72, 38);
            this.idDel.Name = "idDel";
            this.idDel.Size = new System.Drawing.Size(158, 20);
            this.idDel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "ID: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "ID: ";
            // 
            // idIns
            // 
            this.idIns.Location = new System.Drawing.Point(72, 133);
            this.idIns.Name = "idIns";
            this.idIns.Size = new System.Drawing.Size(158, 20);
            this.idIns.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Title:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // titleIns
            // 
            this.titleIns.Location = new System.Drawing.Point(72, 163);
            this.titleIns.Name = "titleIns";
            this.titleIns.Size = new System.Drawing.Size(158, 20);
            this.titleIns.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Author:";
            // 
            // authorIns
            // 
            this.authorIns.Location = new System.Drawing.Point(72, 196);
            this.authorIns.Name = "authorIns";
            this.authorIns.Size = new System.Drawing.Size(158, 20);
            this.authorIns.TabIndex = 8;
            // 
            // btnIns
            // 
            this.btnIns.Location = new System.Drawing.Point(92, 234);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(69, 21);
            this.btnIns.TabIndex = 10;
            this.btnIns.Text = "Insert";
            this.btnIns.UseVisualStyleBackColor = true;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "DELETE ->";
            // 
            // Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnIns);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.authorIns);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.titleIns);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.idIns);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.idDel);
            this.Controls.Add(this.btnDel);
            this.Name = "Books";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Books_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idDel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox idIns;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox titleIns;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox authorIns;
        private System.Windows.Forms.Button btnIns;
        private System.Windows.Forms.Label label6;
    }
}

