﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Books : Form
    {
        public Books()
        {
            InitializeComponent();
        }

        private void Books_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            BooksReference.WebService1SoapClient books = new BooksReference.WebService1SoapClient();
            books.delete(idDel.Text);
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            BooksReference.WebService1SoapClient books = new BooksReference.WebService1SoapClient();
            books.insert(idIns.Text, titleIns.Text, authorIns.Text);
            idIns.ResetText();
            titleIns.ResetText();
            authorIns.ResetText();
        }
    }
}
